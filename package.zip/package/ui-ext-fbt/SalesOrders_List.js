define(function () {

	// New button
	const BTN_GET_COMPANY_LIST = "uuid_get_company_info";

	// Event names
	const onAfterButtonClickBtnGetCompanyInfo = `on${BTN_GET_COMPANY_LIST}AfterButtonClick`;

	return {
		[onAfterButtonClickBtnGetCompanyInfo]: async function (oInst) {
			let resp = await fetch("/svcl/b1s/v1/CompanyService_GetCompanyInfo", {
				method: "POST",
				credentials: "include"
			});
			let json = await resp.json();
			oInst.showMessageBox("Success", `Company Name: ${json.CompanyName}, \r\nVersion: ${json.Version}`, [{
				label: "OK",
				key: "OK"
			}]);
		}
	};
});